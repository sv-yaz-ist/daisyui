import{a as t}from"../chunks/entry.gJkXoJdy.js";export{t as start};
