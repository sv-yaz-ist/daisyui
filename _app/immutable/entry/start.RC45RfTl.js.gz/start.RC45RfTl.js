import{a as t}from"../chunks/entry.qA8_SV2I.js";export{t as start};
