import{a as t}from"../chunks/entry.-N4kNLW_.js";export{t as start};
