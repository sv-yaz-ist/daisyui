import{a as t}from"../chunks/entry.C6-M7uEu.js";export{t as start};
